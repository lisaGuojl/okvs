

The `cmake` script present in this directory offers the following options :

- `BUILD_XXHSUM` : build the command line binary. ON by default
- `BUILD_SHARED_LIBS` : build dynamic library. ON by default.
- `BUILD_ENABLE_INLINE_API` : adds xxhash.c for the `-DXXH_INLINE_ALL` api. ON by default.
